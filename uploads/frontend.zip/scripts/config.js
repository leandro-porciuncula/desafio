// Detecta o ambiente automaticamente (localhost ou produção)
const BACKEND_URL = 'http://98.83.212.170:3000'; // Altere aqui para o IP da sua EC2

